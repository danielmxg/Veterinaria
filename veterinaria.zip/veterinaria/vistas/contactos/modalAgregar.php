

<!-- Modal -->
<div class="modal fade" id="modalAgregarContacto" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Agregar nuevo mascota</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
     <div class="modal-body">
    <form id="frmAgregarContacto">
        <div id="categoriasId"></div>
        <label for="nombre">Alias de la mascota</label>
        <input type="text" class="form-control" id="nombre" name="nombre">
    
        
        <label for="apaterno">Raza de la mascota</label>
        <input type="text" class="form-control" id="apaterno" name="apaterno">
        
        <label for="amaterno">Peso actual de la mascota</label>
        <input type="text" class="form-control" id="amaterno" name="amaterno">
        
        <label for="especie">Especies</label>
        <select class="form-control" id="especie" name="especie">
            <option value="">Selecciona una especie</option>
            <option value="perro">Perro</option>
            <option value="gato">Gato</option>
            <option value="ave">Ave</option>
            <option value="pez">Pez</option>
            <option value="reptil">Reptil</option>
        </select>
        
        <label for="telefono">Teléfono de contacto </label>
        <input type="text" class="form-control" id="telefono" name="telefono">
        
        <label for="email">Email para contactar al cliente</label>
        <input type="text" class="form-control" id="email" name="email">

       
    </form>
</div>

      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
        <button type="button" class="btn btn-primary" id="btnAgregarContacto">Guardar</button>
      </div>
    </div>
  </div>
</div>


<script type="text/javascript">
  $(document).ready(function(){
    $('#categoriasId').load("vistas/contactos/selectCategorias.php");
  });
</script>