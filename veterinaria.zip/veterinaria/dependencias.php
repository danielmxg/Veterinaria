

	<link rel="stylesheet" type="text/css" href="public/bootstrap/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="public/fontawesome/css/all.css">
	<link rel="stylesheet" type="text/css" href="public/datatable/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="public/datatable/dataTables.bootstrap4.min.css">

	<script src="public/jquery-3.5.1.min.js"></script>
	<script src="public/bootstrap/popper.min.js"></script>
	<script src="public/bootstrap/bootstrap.min.js"></script>
	<script src="public/datatable/jquery.dataTables.min.js"></script>
	<script src="public/datatable/dataTables.bootstrap4.min.js"></script>
	<script src="public/sweetalert.min.js"></script>