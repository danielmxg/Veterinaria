<!DOCTYPE html>
<html>
<head>
	<title>Animal friendly</title>
	<link rel="icon" type="image/jpg" href="public/img/logo.png">
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<?php require_once "dependencias.php"; ?>
</head>
<body>
	<div class="container">
		<?php require_once "menu.php"; ?>

		<div class="jumbotron">
			<h1 class="display-4">Animal Friendly</h1>

			<div class="row">
				<div class="col-sm-6">
					<div class="card">
						<div class="card-body">
							<img src="public/img/veterinaria.jpg" class="img-fluid" alt="Responsive image">
						</div>
					</div>
				</div>
				<div class="col-sm-6">
					<div class="card">
						<div class="card-body">
							<table class="table table-hover">
								<tr>
									<th>
									Nuestros Servicios:

<br>-Consultas y chequeos rutinarios
<br>-Vacunación
<br>-Cirugías
<br>-Urgencias veterinarias
<br>-Cuidado dental
<br>-Desparasitación
<br>-y mucho más
									</th>
								</tr>
								<tr>
									<th>
									Agenda tu Cita en Línea
Puedes agendar tu cita fácilmente a través de nuestro calendario en línea o llamarnos directamente para programar la atención que tu mascota necesita.
									</th>
								</tr>
								<tr>
									<th>
									¡En Animal Friendly. tu mascota está en las mejores manos! Contáctanos hoy para más información o para agendar una cita. Estamos aquí para cuidar a tu mejor amigo.
									</th>
								</tr>
							</table>
						</div>
					</div>
				</div>
			</div>

			<hr class="my-4">
			<p>
			Agenda tu Cita en Línea
Puedes agendar tu cita fácilmente a través de nuestro calendario en línea o llamarnos directamente para programar la atención que tu mascota necesita.
			</p>
			
		</div>

	</div>

	
</body>
</html>