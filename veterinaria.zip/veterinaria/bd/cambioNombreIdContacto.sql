ALTER TABLE `agendafa`.`t_contactos` 
CHANGE COLUMN `id_agenda` `id_contacto` INT(11) NOT NULL ;
